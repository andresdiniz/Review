<?php
// src/Form/ProductFilterType.php

namespace App\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\SearchType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class ProductFilterType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder
            ->add('category', ChoiceType::class, [
                'choices' => $options['categories'],
                'placeholder' => 'Todas categorias',
                'required' => false,
                'label' => 'Categoria'
            ])
            ->add('min_price', NumberType::class, [
                'required' => false,
                'label' => 'Preço mínimo',
                'attr' => ['placeholder' => 'R$']
            ])
            ->add('max_price', NumberType::class, [
                'required' => false,
                'label' => 'Preço máximo',
                'attr' => ['placeholder' => 'R$']
            ])
            ->add('search', SearchType::class, [
                'required' => false,
                'label' => 'Buscar',
                'attr' => ['placeholder' => 'Nome do produto']
            ]);
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'method' => 'GET',
            'csrf_protection' => false,
            'categories' => []
        ]);
    }
}
