<?php
// src/Controller/Admin/ProductCrudController.php

namespace App\Controller\Admin;

use App\Entity\Product;
use App\Service\ProductAIService;
use EasyCorp\Bundle\EasyAdminBundle\Config\Action;
use EasyCorp\Bundle\EasyAdminBundle\Config\Actions;
use EasyCorp\Bundle\EasyAdminBundle\Config\Crud;
use EasyCorp\Bundle\EasyAdminBundle\Controller\AbstractCrudController;
use EasyCorp\Bundle\EasyAdminBundle\Field\DateTimeField;
use EasyCorp\Bundle\EasyAdminBundle\Field\IdField;
use EasyCorp\Bundle\EasyAdminBundle\Field\NumberField;
use EasyCorp\Bundle\EasyAdminBundle\Field\SlugField;
use EasyCorp\Bundle\EasyAdminBundle\Field\TextareaField;
use EasyCorp\Bundle\EasyAdminBundle\Field\TextEditorField;
use EasyCorp\Bundle\EasyAdminBundle\Field\TextField;
use EasyCorp\Bundle\EasyAdminBundle\Field\UrlField;
use EasyCorp\Bundle\EasyAdminBundle\Router\AdminUrlGenerator;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use EasyCorp\Bundle\EasyAdminBundle\Field\CollectionField;
use Symfony\Component\Form\Extension\Core\Type\TextType;

class ProductCrudController extends AbstractCrudController
{
    private ProductAIService $productAIService;
    private AdminUrlGenerator $adminUrlGenerator;

    public function __construct(ProductAIService $productAIService, AdminUrlGenerator $adminUrlGenerator)
    {
        $this->productAIService = $productAIService;
        $this->adminUrlGenerator = $adminUrlGenerator;
    }

    public static function getEntityFqcn(): string
    {
        return Product::class;
    }

    public function configureFields(string $pageName): iterable
    {
        $fields = [
            IdField::new('id')->hideOnForm(),
            TextField::new('name'),
            SlugField::new('slug')->setTargetFieldName('name'),
            TextEditorField::new('description')->hideOnIndex(),
            TextareaField::new('aiVerdict')->hideOnIndex(),
            TextEditorField::new('fullReviewMarkdown')->hideOnIndex(),
            UrlField::new('affiliateLink'),
            // Substituindo MoneyField por NumberField para corrigir exibição
            NumberField::new('currentPrice', 'Preço (R$)')
                ->setNumDecimals(2)
                ->setStoredAsString(false)
                ->setFormTypeOption('attr', ['step' => '0.01'])
                ->formatValue(function ($value) {
                    return number_format($value, 2, ',', '.');
                }),
            TextField::new('youtubeVideoId')->hideOnIndex(),
            TextField::new('imageUrl', 'URL da imagem')->hideOnIndex(),
            TextField::new('mercadolivreId', 'ID Mercado Livre')->hideOnIndex(),
            DateTimeField::new('createdAt')->hideOnForm(),
            DateTimeField::new('lastUpdateAt')->hideOnForm(),
        ];

        $prosField = CollectionField::new('pros')
            ->hideOnIndex()
            ->allowAdd(true)
            ->allowDelete(true)
            ->setEntryType(TextType::class)
            ->setEntryIsComplex(false)
            ->setFormTypeOptions([
                'attr' => ['placeholder' => 'Adicione os prós do produto'],
            ]);

        $consField = CollectionField::new('cons')
            ->hideOnIndex()
            ->allowAdd(true)
            ->allowDelete(true)
            ->setEntryType(TextType::class)
            ->setEntryIsComplex(false)
            ->setFormTypeOptions([
                'attr' => ['placeholder' => 'Adicione os contras do produto'],
            ]);

        $fields[] = $prosField;
        $fields[] = $consField;

        return $fields;
    }

    public function configureActions(Actions $actions): Actions
    {
        $generateFromUrl = Action::new('generateFromUrl', 'Gerar a partir de URL', 'fa fa-magic')
            ->linkToCrudAction('generateFromUrl')
            ->createAsGlobalAction()
            ->setCssClass('btn btn-primary');

        return $actions->add(Crud::PAGE_INDEX, $generateFromUrl);
    }

    public function generateFromUrl(Request $request): Response
    {
        if ($request->isMethod('POST')) {
            $url = $request->request->get('affiliate_url');
            if ($url) {
                try {
                    $data = $this->productAIService->generateFromAffiliateLink($url);

                    $product = new Product();
                    $product->setName($data['name']);
                    $product->setSlug($data['slug']);
                    $product->setCurrentPrice($data['currentPrice']);
                    $product->setAffiliateLink($data['affiliateLink']);
                    $product->setAiVerdict($data['aiVerdict']);
                    $product->setPros($data['pros']);
                    $product->setCons($data['cons']);
                    $product->setFullReviewMarkdown($data['fullReviewMarkdown']);
                    $product->setYoutubeVideoId($data['youtubeVideoId']);
                    $product->setImageUrl($data['imageUrl'] ?? null);
                    $product->setMercadolivreId($data['mercadolivreId'] ?? null);
                    // createdAt será preenchido automaticamente pelo callback PrePersist

                    $entityManager = $this->container->get('doctrine')->getManager();
                    $entityManager->persist($product);
                    $entityManager->flush();

                    $this->addFlash('success', 'Produto criado com sucesso a partir do link.');
                    return $this->redirectToRoute('admin', [
                        'crudAction' => 'index',
                        'crudControllerFqcn' => self::class,
                    ]);
                } catch (\Exception $e) {
                    $this->addFlash('danger', 'Erro ao gerar: ' . $e->getMessage());
                }
            } else {
                $this->addFlash('danger', 'Informe uma URL válida.');
            }
        }

        return $this->render('admin/generate_from_url.html.twig', [
            'action' => $this->adminUrlGenerator->setAction('generateFromUrl')->generateUrl(),
        ]);
    }
}
