<?php

namespace App\Controller;

use App\Entity\Product;
use App\Form\ProductFilterType;
use App\Repository\ProductRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bridge\Doctrine\Attribute\MapEntity;


class ProductController extends AbstractController
{
    #[Route('/', name: 'product_index')]
    public function index(Request $request, ProductRepository $productRepository): Response
    {
        // Obtém categorias para o filtro
        $categories = $productRepository->createQueryBuilder('p')
            ->select('DISTINCT p.category')
            ->where('p.category IS NOT NULL')
            ->getQuery()
            ->getSingleColumnResult();

        $form = $this->createForm(ProductFilterType::class, null, ['categories' => $categories]);
        $form->handleRequest($request);

        $filters = [];
        if ($form->isSubmitted() && $form->isValid()) {
            $filters = $form->getData();
        }

        $products = $productRepository->findFiltered($filters);

        return $this->render('product/index.html.twig', [
            'products' => $products,
            'filter_form' => $form->createView(),
        ]);
    }

    #[Route('/product/{slug}', name: 'product_show')]
    public function show(#[MapEntity(mapping: ['slug' => 'slug'])] Product $product): Response
    {
        return $this->render('product/show.html.twig', [
            'product' => $product,
        ]);
    }
}
