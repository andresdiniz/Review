<?php
// src/Repository/ProductRepository.php

namespace App\Repository;

use App\Entity\Product;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

class ProductRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Product::class);
    }

    public function findFiltered(array $filters): array
    {
        $qb = $this->createQueryBuilder('p');

        if (!empty($filters['category'])) {
            $qb->andWhere('p.category = :category')
               ->setParameter('category', $filters['category']);
        }

        if (!empty($filters['min_price'])) {
            $qb->andWhere('p.currentPrice >= :minPrice')
               ->setParameter('minPrice', $filters['min_price']);
        }

        if (!empty($filters['max_price'])) {
            $qb->andWhere('p.currentPrice <= :maxPrice')
               ->setParameter('maxPrice', $filters['max_price']);
        }

        if (!empty($filters['search'])) {
            $qb->andWhere('p.name LIKE :search')
               ->setParameter('search', '%'.$filters['search'].'%');
        }

        // Ordenação padrão
        $qb->orderBy('p.createdAt', 'DESC');

        return $qb->getQuery()->getResult();
    }
}
