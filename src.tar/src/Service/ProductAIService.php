<?php
// src/Service/ProductAIService.php

namespace App\Service;

class ProductAIService
{
    private MercadoLivreScraperService $scraper;
    private GeminiService $gemini;

    public function __construct(MercadoLivreScraperService $scraper, GeminiService $gemini)
    {
        $this->scraper = $scraper;
        $this->gemini = $gemini;
    }

    public function generateFromAffiliateLink(string $url): array
    {
        $productData = $this->scraper->extractFromUrl($url);
        $reviewData = $this->gemini->generateReview($productData);

        return [
            'name' => $productData['name'],
            'slug' => $this->slugify($productData['name']),
            'currentPrice' => $productData['price'],
            'affiliateLink' => $productData['url'],
            'aiVerdict' => $reviewData['aiVerdict'],
            'pros' => $reviewData['pros'],
            'cons' => $reviewData['cons'],
            'fullReviewMarkdown' => $reviewData['fullReviewMarkdown'],
            'youtubeVideoId' => null,
            'imageUrl' => $productData['imageUrl'],
            'mercadolivreId' => $productData['mercadolivreId'],
        ];
    }

    private function slugify(string $text): string
    {
        $text = preg_replace('~[^\pL\d]+~u', '-', $text);
        $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);
        $text = preg_replace('~[^-\w]+~', '', $text);
        $text = trim($text, '-');
        $text = strtolower($text);
        return empty($text) ? 'n-a' : $text;
    }
}
