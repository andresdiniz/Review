<?php
// src/Service/ProductCreationService.php

namespace App\Service;

use App\Entity\Product;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Contracts\HttpClient\HttpClientInterface;

class ProductCreationService
{
    public function __construct(
        private EntityManagerInterface $em,
        private HttpClientInterface $httpClient
    ) {}

    public function createFromUrl(string $url): Product
    {
        // 1. Extrair dados do produto da URL (scraper)
        $scrapedData = $this->scrapeProductData($url);

        // 2. Enviar para IA (exemplo com OpenAI)
        $aiData = $this->generateReviewWithAI($scrapedData);

        // 3. Criar entidade e persistir
        $product = new Product();
        $product->setName($scrapedData['name']);
        $product->setAffiliateLink($url);
        $product->setCurrentPrice($scrapedData['price']);
        $product->setAiVerdict($aiData['verdict']);
        $product->setPros($aiData['pros']);
        $product->setCons($aiData['cons']);
        $product->setFullReviewMarkdown($aiData['review_markdown']);
        $product->setCreatedAt(new \DateTimeImmutable());

        $this->em->persist($product);
        $this->em->flush();

        return $product;
    }

    private function scrapeProductData(string $url): array
    {
        // Implemente scraping ou use APIs oficiais
        return []; // retorno de exemplo
    }

    private function generateReviewWithAI(array $data): array
    {
        // Chame API da OpenAI com um prompt estruturado pedindo JSON
        // Exemplo de resposta: ['verdict' => '...', 'pros' => [...], 'cons' => [...], 'review_markdown' => '...']
        return [];
    }
}
