<?php

namespace App\Service;

use Symfony\Contracts\HttpClient\HttpClientInterface;

class GeminiService
{
    private HttpClientInterface $httpClient;
    private string $apiKey;

    public function __construct(HttpClientInterface $httpClient, string $apiKey)
    {
        $this->httpClient = $httpClient;
        $this->apiKey = $apiKey;
    }

    public function generateReview(array $productData): array
    {
        $prompt = <<<PROMPT
        Você é um especialista em reviews de produtos. Com base nas informações abaixo, crie uma análise completa do produto.

        Nome: {$productData['name']}
        Descrição: {$productData['description']}
        Categoria: {$productData['category']}
        Condição: {$productData['condition']}

        Gere uma review em português que inclua:
        - Um título criativo
        - Um texto descritivo e persuasivo (pode usar markdown)
        - Uma lista de 3-5 prós
        - Uma lista de 3-5 contras
        - Um veredito final

        Formato da resposta (JSON puro, sem outros comentários):
        {
            "title": "título da review",
            "reviewMarkdown": "texto em markdown",
            "pros": ["pró 1", "pró 2", ...],
            "cons": ["contra 1", "contra 2", ...],
            "verdict": "veredito"
        }
        PROMPT;

        $response = $this->httpClient->request('POST', 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent', [
            'query' => ['key' => $this->apiKey],
            'json' => [
                'contents' => [
                    [
                        'parts' => [
                            ['text' => $prompt]
                        ]
                    ]
                ],
                'generationConfig' => [
                    'temperature' => 0.7,
                    'maxOutputTokens' => 2048,
                ]
            ]
        ]);

        $data = $response->toArray();

        // Extrai o texto gerado
        $text = $data['candidates'][0]['content']['parts'][0]['text'] ?? '';

        // Tenta extrair o JSON da resposta
        if (preg_match('/\{.*\}/s', $text, $matches)) {
            $result = json_decode($matches[0], true);
        } else {
            $result = [];
        }

        return [
            'fullReviewMarkdown' => $result['reviewMarkdown'] ?? $text,
            'pros' => $result['pros'] ?? [],
            'cons' => $result['cons'] ?? [],
            'aiVerdict' => $result['verdict'] ?? '',
        ];
    }
}
