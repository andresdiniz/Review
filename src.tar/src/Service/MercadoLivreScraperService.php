<?php
// src/Service/MercadoLivreScraperService.php

namespace App\Service;

use Symfony\Contracts\HttpClient\HttpClientInterface;

class MercadoLivreScraperService
{
    private HttpClientInterface $httpClient;

    public function __construct(HttpClientInterface $httpClient)
    {
        $this->httpClient = $httpClient;
    }

    public function extractFromUrl(string $url): array
    {
        // Extrai o ID numérico do produto
        if (preg_match('/[A-Z]{3}-(\d+)/', $url, $matches)) {
            $productId = $matches[1];
        } else {
            throw new \Exception('URL inválida – não foi possível identificar o produto');
        }

        $apiUrl = "https://api.mercadolibre.com/items/$productId";
        $response = $this->httpClient->request('GET', $apiUrl);
        $data = $response->toArray();

        $descUrl = "https://api.mercadolibre.com/items/$productId/description";
        $descResponse = $this->httpClient->request('GET', $descUrl);
        $descData = $descResponse->toArray();
        $description = $descData['plain_text'] ?? '';

        // Obtém a primeira imagem, se existir
        $pictures = $data['pictures'] ?? [];
        $imageUrl = !empty($pictures) ? $pictures[0]['url'] ?? null : null;

        return [
            'name' => $data['title'],
            'price' => $data['price'],
            'currency' => $data['currency_id'],
            'description' => $description,
            'category' => $data['category_id'],
            'condition' => $data['condition'],
            'pictures' => $pictures,
            'url' => $data['permalink'],
            'imageUrl' => $imageUrl,
            'mercadolivreId' => $productId,
        ];
    }
}
