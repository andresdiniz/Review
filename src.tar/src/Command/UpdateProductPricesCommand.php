<?php
// src/Command/UpdateProductPricesCommand.php

namespace App\Command;

use App\Repository\ProductRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Contracts\HttpClient\HttpClientInterface;
use Symfony\Contracts\HttpClient\Exception\TransportExceptionInterface;

#[AsCommand(name: 'app:update-prices', description: 'Atualiza preços dos produtos via API do Mercado Livre')]
class UpdateProductPricesCommand extends Command
{
    public function __construct(
        private ProductRepository $productRepository,
        private EntityManagerInterface $em,
        private HttpClientInterface $httpClient
    ) {
        parent::__construct();
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $products = $this->productRepository->findAll();
        $output->writeln(sprintf('Atualizando preços de %d produtos...', count($products)));

        $updated = 0;
        $errors = 0;

        foreach ($products as $product) {
            // 1. Tenta usar o ID armazenado (mercadolivreId)
            $productId = $product->getMercadolivreId();

            if (!$productId) {
                $affiliateLink = $product->getAffiliateLink();
                if (!$affiliateLink) {
                    $output->writeln(sprintf('<comment>Produto %s não possui link nem ID, ignorando.</comment>', $product->getName()));
                    continue;
                }

                $finalUrl = $this->followRedirects($affiliateLink, $output);
                if (!$finalUrl) {
                    $output->writeln(sprintf('<error>Não foi possível acessar a URL: %s</error>', $affiliateLink));
                    $errors++;
                    continue;
                }

                $productId = $this->extractProductIdFromUrl($finalUrl);
            }

            if (!$productId) {
                $output->writeln(sprintf('<error>Não foi possível obter ID do produto: %s</error>', $product->getName()));
                $errors++;
                continue;
            }

            try {
                $apiUrl = sprintf('https://api.mercadolibre.com/items/%s', $productId);
                $response = $this->httpClient->request('GET', $apiUrl);
                $data = $response->toArray();

                $newPrice = $data['price'] ?? null;
                if ($newPrice !== null) {
                    $oldPrice = $product->getCurrentPrice();
                    $product->setCurrentPrice($newPrice);
                    $product->setLastUpdateAt(new \DateTimeImmutable());
                    $this->em->flush();
                    $updated++;
                    $output->writeln(sprintf('Atualizado: %s - R$ %s (antes: R$ %s)', $product->getName(), $newPrice, $oldPrice));
                } else {
                    $output->writeln(sprintf('<warning>Produto %s: preço não encontrado na resposta da API.</warning>', $product->getName()));
                    $errors++;
                }
            } catch (TransportExceptionInterface $e) {
                $output->writeln(sprintf('<error>Erro de conexão ao atualizar %s: %s</error>', $product->getName(), $e->getMessage()));
                $errors++;
            } catch (\Exception $e) {
                $output->writeln(sprintf('<error>Erro ao atualizar %s: %s</error>', $product->getName(), $e->getMessage()));
                $errors++;
            }
        }

        $output->writeln(sprintf('Concluído. Atualizados: %d, Erros: %d', $updated, $errors));
        return Command::SUCCESS;
    }

    private function followRedirects(string $url, OutputInterface $output): ?string
    {
        try {
            $response = $this->httpClient->request('GET', $url, [
                'max_redirects' => 5,
                'headers' => [
                    'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
                    'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
                    'Accept-Language' => 'pt-BR,pt;q=0.9,en;q=0.8',
                    'Accept-Encoding' => 'gzip, deflate, br',
                ],
            ]);
            $finalUrl = $response->getInfo('url');

            if (str_contains($finalUrl, '/social/') || str_contains($finalUrl, 'profile')) {
                $output->writeln(sprintf('<error>O link %s redirecionou para um perfil social, não é um link de produto.</error>', $url));
                return null;
            }

            return $finalUrl;
        } catch (\Exception $e) {
            $output->writeln(sprintf('<error>Erro ao seguir redirecionamento de %s: %s</error>', $url, $e->getMessage()));
            return null;
        }
    }

    private function extractProductIdFromUrl(string $url): ?string
    {
        if (preg_match('/[A-Z]{3}-(\d+)/', $url, $matches)) {
            return $matches[1];
        }
        if (preg_match('/\/(\d+)\/?$/', $url, $matches)) {
            return $matches[1];
        }
        return null;
    }
}
